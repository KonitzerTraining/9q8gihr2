export interface Customer {
    id: number;
    name: string;
    credit: number;
}
