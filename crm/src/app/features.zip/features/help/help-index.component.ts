import { Component } from '@angular/core';

@Component({
  selector: 'app-help-index',
  templateUrl: './help-index.component.html'
})
export class HelpIndexComponent {

}
